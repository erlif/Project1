## Silverstripe Assets Module

[![CI](https://github.com/silverstripe/silverstripe-assets/actions/workflows/ci.yml/badge.svg)](https://github.com/silverstripe/silverstripe-assets/actions/workflows/ci.yml)
[![Silverstripe supported module](https://img.shields.io/badge/silverstripe-supported-0071C4.svg)](https://www.silverstripe.org/software/addons/silverstripe-commercially-supported-module-list/)

Required component of [Silverstripe Framework](https://github.com/silverstripe/silverstripe-framework)

## Installation

```sh
composer require silverstripe/assets
```

## Links ##

 * [License](./LICENSE)
