<?php

namespace SilverStripe\Forms\GridField;

use SilverStripe\Core\Injector\Injectable;

abstract class AbstractGridFieldComponent implements GridFieldComponent
{
    use Injectable;
}
