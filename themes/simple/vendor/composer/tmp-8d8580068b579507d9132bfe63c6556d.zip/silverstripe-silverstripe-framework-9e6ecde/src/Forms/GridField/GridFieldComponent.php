<?php

namespace SilverStripe\Forms\GridField;

/**
 * Base interface for all components that can be added to GridField.
 */
interface GridFieldComponent
{
}
