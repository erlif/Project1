<?php

namespace SilverStripe\Dev;

/**
 * Classes that implement TestOnly are only to be used during testing
 */
interface TestOnly
{

}
