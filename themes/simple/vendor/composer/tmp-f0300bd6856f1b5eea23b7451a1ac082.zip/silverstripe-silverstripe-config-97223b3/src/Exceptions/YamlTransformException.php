<?php

namespace SilverStripe\Config\Exceptions;

use Exception;

class YamlTransformException extends Exception
{
}
